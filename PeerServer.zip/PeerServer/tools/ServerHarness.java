import android.peer.server.core.*;
public class ServerHarness {
    public static void main(String[] a) throws Exception {
        ServerConfig c = ServerConfig.fromJson("{\"port\":9911,\"path\":\"/myapp\",\"key\":\"k1\",\"concurrentLimit\":4,\"aliveTimeout\":8000,\"expireTimeout\":1500}");
        PeerEngine e = new PeerEngine(c, new PeerEngine.Listener() {
            public void onLog(String l, String m) { System.out.println("[" + l + "] " + m); }
            public void onPeersChanged() {}
            public void onTraffic(String t, String s, String d) { System.out.println("  traffic " + t + " " + s + "->" + d); }
        });
        e.start();
        Thread.sleep(Long.parseLong(a.length > 0 ? a[0] : "60000"));
        System.out.println(Json.stringify(e.snapshot()));
        e.stop();
    }
}
