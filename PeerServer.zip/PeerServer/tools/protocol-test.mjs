const B = "127.0.0.1:9911";
let fails = 0;
const ok = (c, m) => { if (!c) { fails++; console.log("FAIL:", m); } else console.log("ok  :", m); };
const sleep = ms => new Promise(r => setTimeout(r, ms));
function ws(id, token, key = "k1", path = "/myapp/peerjs") {
  return new Promise((res) => {
    const s = new WebSocket(`ws://${B}${path}?key=${key}&id=${id}&token=${token}`);
    const o = { s, msgs: [], closed: false, code: null };
    s.onmessage = e => o.msgs.push(JSON.parse(e.data));
    s.onclose = e => { o.closed = true; o.code = e.code; };
    s.onopen = () => res(o);
    s.onerror = () => res(o);
  });
}
// HTTP
let r = await fetch(`http://${B}/myapp`); let j = await r.json();
ok(r.status === 200 && j.name === "PeerJS Server", "GET /myapp info " + JSON.stringify(j).slice(0, 40));
ok(r.headers.get("access-control-allow-origin") === "*", "CORS header present");
r = await fetch(`http://${B}/myapp/k1/id`); let id = await r.text();
ok(r.status === 200 && id.length === 8, "GET /k1/id -> " + id);
r = await fetch(`http://${B}/myapp/wrong/id`); ok(r.status === 401, "wrong key 401");
r = await fetch(`http://${B}/myapp/k1/peers`); ok((await r.json()).length === 0, "peers empty");
r = await fetch(`http://${B}/nothing`); ok(r.status === 404, "404 elsewhere");
r = await fetch(`http://${B}/myapp/k1/id`, { method: "OPTIONS" }); ok(r.status === 204, "OPTIONS 204");

// WS basics
const a = await ws("alice", "tokA"); await sleep(150);
ok(a.msgs[0]?.type === "OPEN", "alice gets OPEN");
const b = await ws("bob", "tokB"); await sleep(150);
ok(b.msgs[0]?.type === "OPEN", "bob gets OPEN");
r = await fetch(`http://${B}/myapp/k1/peers`); ok(JSON.stringify(await r.json()) === '["alice","bob"]', "peers lists alice,bob");

// relay + src spoofing override
a.s.send(JSON.stringify({ type: "OFFER", dst: "bob", src: "evil", payload: { sdp: { type: "offer", sdp: "v=0\r\n\"quoted\" ünï" }, type: "data", connectionId: "dc_1", metadata: { a: [1, 2.5, null, true] } } }));
await sleep(200);
const off = b.msgs.find(m => m.type === "OFFER");
ok(off && off.src === "alice", "OFFER relayed with server-set src (spoof overridden)");
ok(off && off.payload.sdp.sdp === "v=0\r\n\"quoted\" ünï" && off.payload.metadata.a[1] === 2.5, "payload intact incl. escapes/unicode");
b.s.send(JSON.stringify({ type: "ANSWER", dst: "alice", payload: { sdp: { type: "answer", sdp: "x" }, connectionId: "dc_1" } }));
a.s.send(JSON.stringify({ type: "CANDIDATE", dst: "bob", payload: { candidate: { candidate: "c" }, connectionId: "dc_1" } }));
await sleep(200);
ok(a.msgs.some(m => m.type === "ANSWER" && m.src === "bob"), "ANSWER relayed");
ok(b.msgs.some(m => m.type === "CANDIDATE" && m.src === "alice"), "CANDIDATE relayed");

// heartbeat accepted silently
a.s.send(JSON.stringify({ type: "HEARTBEAT" })); await sleep(100);
ok(!a.closed, "heartbeat ok");

// ID taken
const dup = await ws("alice", "other"); await sleep(250);
ok(dup.msgs[0]?.type === "ID-TAKEN" && dup.closed, "ID-TAKEN for wrong token + closed");
ok(!a.closed, "original alice unaffected");

// invalid key / missing params
const bad = await ws("zed", "t", "nope"); await sleep(250);
ok(bad.msgs[0]?.type === "ERROR" && bad.msgs[0].payload.msg === "Invalid key provided" && bad.closed, "invalid key ERROR");
const miss = await new Promise(res => { const s = new WebSocket(`ws://${B}/myapp/peerjs?key=k1`); const o = { msgs: [], closed: false }; s.onmessage = e => o.msgs.push(JSON.parse(e.data)); s.onclose = () => { o.closed = true; }; s.onopen = () => res(o); });
await sleep(250);
ok(miss.msgs[0]?.payload?.msg.startsWith("No id, token"), "missing params ERROR");

// queue + flush on connect
a.s.send(JSON.stringify({ type: "OFFER", dst: "carol", payload: { connectionId: "dc_q" } }));
await sleep(300);
const c = await ws("carol", "tokC"); await sleep(300);
ok(c.msgs.some(m => m.type === "OFFER" && m.src === "alice"), "queued OFFER flushed to late peer");

// expire
a.s.send(JSON.stringify({ type: "OFFER", dst: "ghost", payload: { connectionId: "dc_x" } }));
await sleep(3200);
ok(a.msgs.some(m => m.type === "EXPIRE" && m.src === "ghost"), "EXPIRE sent to src for unavailable peer");

// concurrent limit (limit 4: alice,bob,carol + one more ok, fifth rejected)
const d4 = await ws("d4", "t"); await sleep(150);
const d5 = await ws("d5", "t"); await sleep(250);
ok(d5.msgs[0]?.type === "ERROR" && /concurrent user limit/.test(d5.msgs[0].payload.msg), "concurrent limit enforced");
d4.s.close(); await sleep(200);

// LEAVE relay + disconnect cleanup
b.s.close(); await sleep(300);
r = await fetch(`http://${B}/myapp/k1/peers`); const ps = await r.json();
ok(!ps.includes("bob") && ps.includes("alice"), "bob removed after close: " + JSON.stringify(ps));
// reconnect same id with new token after leave
const b2 = await ws("bob", "newTok"); await sleep(200);
ok(b2.msgs[0]?.type === "OPEN", "bob can re-register after leaving");

// same-token takeover
const a2 = await ws("alice", "tokA"); await sleep(250);
ok(a2.msgs[0]?.type === "OPEN", "same-token reconnect gets OPEN");
ok(a.closed, "old alice socket closed on takeover");
r = await fetch(`http://${B}/myapp/k1/peers`); ok((await r.json()).includes("alice"), "alice still registered after takeover");

// heartbeat timeout (aliveTimeout 8s): c never heartbeats
await sleep(9500);
r = await fetch(`http://${B}/myapp/k1/peers`); const ps2 = await r.json();
ok(!ps2.includes("carol"), "carol dropped by heartbeat timeout: " + JSON.stringify(ps2));

// large message ok (SDP-sized) and >64KB frame (16-bit/64-bit length path)
const big = "x".repeat(70000);
const x1 = await ws("x1", "t"); const x2 = await ws("x2", "t"); await sleep(200);
x1.s.send(JSON.stringify({ type: "OFFER", dst: "x2", payload: { big } })); await sleep(500);
ok(x2.msgs.some(m => m.type === "OFFER" && m.payload.big.length === 70000), "70KB message relayed (64-bit length frame)");
const mid = "y".repeat(5000);
x2.s.send(JSON.stringify({ type: "ANSWER", dst: "x1", payload: { mid } })); await sleep(300);
ok(x1.msgs.some(m => m.type === "ANSWER" && m.payload.mid.length === 5000), "5KB message relayed (16-bit length frame)");
x1.s.send(JSON.stringify({ type: "LEAVE", dst: "x2", payload: {} })); await sleep(200);
ok(x2.msgs.some(m => m.type === "LEAVE" && m.src === "x1"), "LEAVE relayed");
x2.s.send("not json"); x2.s.send(JSON.stringify({ type: "BOGUS" })); await sleep(200);
ok(!x2.closed, "garbage input does not kill the connection");

console.log(fails ? `\n${fails} FAILURES` : "\nALL PASSED");
process.exit(fails ? 1 : 0);
