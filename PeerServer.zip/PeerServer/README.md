# Peer Server

Android app (`android.peer.server`) that runs a **PeerJS-compatible signalling server** on your phone and includes a **PeerJS client hub** for testing, relaying, chatting, transferring files and calling.

## Build the APK on GitHub
1. Create a repo. Upload `PeerServer.zip` (this project) to the repo root and `build.yml` to `.github/workflows/build.yml`.
2. Open **Actions > Build Peer Server APK**. It runs on every push, or press **Run workflow**.
3. Download `PeerServer-apk` from the run's artifacts.

The build downloads `peerjs.min.js` (v1.5.4) into the app's assets, so the hub works offline afterwards.
Optional repo secrets for a stable signing key (otherwise a throw-away key is generated per run, so reinstall instead of updating):
`KEYSTORE_BASE64`, `KEYSTORE_PASSWORD`, `KEY_ALIAS`, `KEY_PASSWORD`.

Local build: JDK 17, Android SDK 34, then `gradle assembleRelease` (Gradle 8.7).

## What the server implements (same wire protocol as `peerjs-server`)
- WebSocket `ws://host:port{path}peerjs?key=&id=&token=` with OPEN, ID-TAKEN, ERROR, HEARTBEAT, OFFER, ANSWER, CANDIDATE, LEAVE, EXPIRE
- HTTP: `{path}` info JSON, `{path}{key}/id`, `{path}{key}/peers` (when discovery is on), legacy `POST {path}{key}/{id}/{token}/{offer|answer|candidate|leave}`
- Options: port, path, key, concurrent limit, allow discovery, alive timeout, expire timeout, ID prefix/length, CORS origin, proxied
- Message queueing for peers that are not online yet, with EXPIRE notices; heartbeat timeouts; kick, block by IP
- Runs in a foreground service (wake and Wi-Fi locks, Stop action, start on boot, start on launch)

Everything is in `app/src/main/java/android/peer/server/core` (pure Java, no Android dependencies).
`tools/` holds the harness used to test the protocol against a real WebSocket client:
`java ServerHarness` then `node protocol-test.mjs` (Node 22).

## Notes
- No TLS: browsers on an `https://` page need `wss://`, so put a TLS reverse proxy in front for that case.
- The hub peer lives in the app's WebView: it stays alive in the background while the server is running.
- File transfer needs `binary` serialization (the PeerJS default).
- Package names starting with `android.` install fine by sideloading but cannot be published on Google Play.
