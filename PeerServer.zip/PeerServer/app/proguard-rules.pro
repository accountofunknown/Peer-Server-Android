# JavaScript bridge methods are called by name from the WebView.
-keepclassmembers class android.peer.server.Bridge {
    @android.webkit.JavascriptInterface <methods>;
}
-keepattributes JavascriptInterface
-keep class android.peer.server.core.** { *; }
-dontwarn com.google.zxing.**
