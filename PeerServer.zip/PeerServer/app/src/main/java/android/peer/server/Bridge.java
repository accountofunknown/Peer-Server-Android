package android.peer.server;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.os.PowerManager;
import android.provider.MediaStore;
import android.provider.Settings;
import android.util.Base64;
import android.webkit.JavascriptInterface;

import androidx.core.content.ContextCompat;

import com.google.zxing.BarcodeFormat;
import com.google.zxing.EncodeHintType;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.qrcode.QRCodeWriter;
import com.google.zxing.qrcode.decoder.ErrorCorrectionLevel;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.EnumMap;
import java.util.Map;

/** JavaScript interface exposed to the UI as window.PeerNative. Every method returns a plain string. */
public final class Bridge {
    private final MainActivity act;
    private final ServerController ctl = ServerController.get();

    Bridge(MainActivity act) { this.act = act; }

    @JavascriptInterface public String getState() { return ctl.stateJson(); }

    @JavascriptInterface public String getLogs() { return ctl.logsJson(); }

    @JavascriptInterface public String startServer(String configJson) {
        ctl.saveConfig(configJson);
        ContextCompat.startForegroundService(act, new Intent(act, PeerService.class).setAction(PeerService.ACTION_START));
        return "ok";
    }

    @JavascriptInterface public String stopServer() {
        act.startService(new Intent(act, PeerService.class).setAction(PeerService.ACTION_STOP));
        return "ok";
    }

    @JavascriptInterface public String saveConfig(String configJson) {
        ctl.saveConfig(configJson);
        return "ok";
    }

    @JavascriptInterface public String saveSettings(String json) { return ctl.saveSettings(json) ? "ok" : "ERROR: invalid settings"; }

    @JavascriptInterface public String kick(String id) { return ctl.kick(id) ? "ok" : "ERROR: not connected"; }

    @JavascriptInterface public String kickAll() { return String.valueOf(ctl.kickAll()); }

    @JavascriptInterface public String block(String ip) { ctl.block(ip); return "ok"; }

    @JavascriptInterface public String unblock(String ip) { ctl.unblock(ip); return "ok"; }

    @JavascriptInterface public void setHubActive(boolean active) { act.hubActive = active; }

    @JavascriptInterface public void keepScreenOn(final boolean on) {
        act.runOnUiThread(new Runnable() {
            @Override public void run() {
                if (on) act.getWindow().addFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
                else act.getWindow().clearFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
            }
        });
    }

    @JavascriptInterface public void copy(final String text) {
        act.runOnUiThread(new Runnable() {
            @Override public void run() {
                ClipboardManager cm = (ClipboardManager) act.getSystemService(Context.CLIPBOARD_SERVICE);
                if (cm != null) cm.setPrimaryClip(ClipData.newPlainText("Peer Server", text));
            }
        });
    }

    @JavascriptInterface public void share(final String text) {
        act.runOnUiThread(new Runnable() {
            @Override public void run() {
                Intent i = new Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, text);
                act.startActivity(Intent.createChooser(i, "Share").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
            }
        });
    }

    @JavascriptInterface public void openUrl(final String url) {
        act.runOnUiThread(new Runnable() {
            @Override public void run() {
                try {
                    act.startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
                } catch (RuntimeException ignored) { }
            }
        });
    }

    @JavascriptInterface public void batterySettings() {
        act.runOnUiThread(new Runnable() {
            @Override public void run() {
                try {
                    PowerManager pm = (PowerManager) act.getSystemService(Context.POWER_SERVICE);
                    if (pm != null && pm.isIgnoringBatteryOptimizations(act.getPackageName())) {
                        act.startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                                Uri.parse("package:" + act.getPackageName())).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
                    } else {
                        act.startActivity(new Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
                    }
                } catch (RuntimeException ignored) { }
            }
        });
    }

    /** Returns a PNG data URL for the QR code, or "" on failure. */
    @JavascriptInterface public String qr(String text, int px) {
        try {
            int size = Math.max(128, Math.min(1024, px));
            Map<EncodeHintType, Object> hints = new EnumMap<>(EncodeHintType.class);
            hints.put(EncodeHintType.MARGIN, 1);
            hints.put(EncodeHintType.ERROR_CORRECTION_LEVEL, ErrorCorrectionLevel.M);
            hints.put(EncodeHintType.CHARACTER_SET, "UTF-8");
            BitMatrix m = new QRCodeWriter().encode(text, BarcodeFormat.QR_CODE, size, size, hints);
            int w = m.getWidth(), h = m.getHeight();
            int[] px32 = new int[w * h];
            int ink = Color.parseColor("#0E0B0A"), paper = Color.parseColor("#EFE6D8");
            for (int y = 0; y < h; y++) for (int x = 0; x < w; x++) px32[y * w + x] = m.get(x, y) ? ink : paper;
            Bitmap bmp = Bitmap.createBitmap(px32, w, h, Bitmap.Config.ARGB_8888);
            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            bmp.compress(Bitmap.CompressFormat.PNG, 100, bos);
            return "data:image/png;base64," + Base64.encodeToString(bos.toByteArray(), Base64.NO_WRAP);
        } catch (Exception e) {
            return "";
        }
    }

    /** Saves base64 data into Downloads/PeerServer. Returns the location, or a string starting with "ERROR:". */
    @JavascriptInterface public String saveFile(String name, String mime, String base64) {
        try {
            byte[] data = Base64.decode(base64, Base64.DEFAULT);
            String safe = name == null ? "file" : name.replaceAll("[\\\\/:*?\"<>|]", "_").trim();
            if (safe.isEmpty()) safe = "file";
            if (Build.VERSION.SDK_INT >= 29) {
                ContentResolver cr = act.getContentResolver();
                ContentValues v = new ContentValues();
                v.put(MediaStore.Downloads.DISPLAY_NAME, safe);
                v.put(MediaStore.Downloads.MIME_TYPE, mime == null || mime.isEmpty() ? "application/octet-stream" : mime);
                v.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/PeerServer");
                Uri u = cr.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v);
                if (u == null) throw new IOException("Storage refused the file");
                try (OutputStream o = cr.openOutputStream(u)) {
                    if (o == null) throw new IOException("Cannot open output");
                    o.write(data);
                }
                return "Downloads/PeerServer/" + safe;
            }
            File dir = act.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS);
            if (dir == null) dir = act.getFilesDir();
            File f = new File(dir, safe);
            try (FileOutputStream o = new FileOutputStream(f)) { o.write(data); }
            return f.getAbsolutePath();
        } catch (Exception e) {
            return "ERROR: " + e.getMessage();
        }
    }
}
