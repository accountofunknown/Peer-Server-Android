package android.peer.server;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.ViewGroup;
import android.webkit.ConsoleMessage;
import android.webkit.PermissionRequest;
import android.webkit.RenderProcessGoneDetail;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.util.Log;

import androidx.activity.ComponentActivity;
import androidx.activity.OnBackPressedCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.core.content.ContextCompat;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsControllerCompat;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class MainActivity extends ComponentActivity implements ServerController.UiListener {
    private static final String TAG = "PeerServer";
    private static final String INK = "#0E0B0A";

    private WebView web;
    volatile boolean hubActive;
    private ValueCallback<Uri[]> fileCallback;
    private PermissionRequest pendingRequest;
    private ActivityResultLauncher<Intent> fileLauncher;
    private ActivityResultLauncher<String[]> permLauncher;
    private ActivityResultLauncher<String> notifLauncher;

    @SuppressLint({"SetJavaScriptEnabled", "AddJavascriptInterface"})
    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        final ServerController ctl = ServerController.get();
        ctl.init(this);

        int ink = Color.parseColor(INK);
        getWindow().setStatusBarColor(ink);
        getWindow().setNavigationBarColor(ink);
        WindowInsetsControllerCompat wic = WindowCompat.getInsetsController(getWindow(), getWindow().getDecorView());
        wic.setAppearanceLightStatusBars(false);
        wic.setAppearanceLightNavigationBars(false);

        fileLauncher = registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), result -> {
            Uri[] uris = null;
            if (result.getResultCode() == RESULT_OK && result.getData() != null) {
                uris = WebChromeClient.FileChooserParams.parseResult(result.getResultCode(), result.getData());
            }
            if (fileCallback != null) fileCallback.onReceiveValue(uris);
            fileCallback = null;
        });
        permLauncher = registerForActivityResult(new ActivityResultContracts.RequestMultiplePermissions(), result -> {
            PermissionRequest req = pendingRequest;
            pendingRequest = null;
            if (req == null) return;
            boolean all = true;
            for (boolean g : result.values()) all &= g;
            if (all) req.grant(req.getResources()); else req.deny();
        });
        notifLauncher = registerForActivityResult(new ActivityResultContracts.RequestPermission(), granted -> { });

        web = new WebView(this);
        web.setBackgroundColor(ink);
        web.setLayoutParams(new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(false);
        s.setAllowFileAccessFromFileURLs(false);
        s.setAllowUniversalAccessFromFileURLs(false);
        s.setSupportZoom(false);
        s.setBuiltInZoomControls(false);
        s.setTextZoom(100);
        s.setCacheMode(WebSettings.LOAD_DEFAULT);
        web.setOverScrollMode(WebView.OVER_SCROLL_NEVER);
        WebView.setWebContentsDebuggingEnabled((getApplicationInfo().flags & android.content.pm.ApplicationInfo.FLAG_DEBUGGABLE) != 0);
        web.addJavascriptInterface(new Bridge(this), "PeerNative");

        web.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri u = request.getUrl();
                if ("file".equals(u.getScheme())) return false;
                try { startActivity(new Intent(Intent.ACTION_VIEW, u)); } catch (RuntimeException ignored) { }
                return true;
            }

            @Override public boolean onRenderProcessGone(WebView view, RenderProcessGoneDetail detail) {
                Log.e(TAG, "WebView render process gone; recreating");
                runOnUiThread(() -> recreate());
                return true;
            }
        });
        web.setWebChromeClient(new WebChromeClient() {
            @Override public void onPermissionRequest(final PermissionRequest request) {
                runOnUiThread(() -> handlePermissionRequest(request));
            }

            @Override public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> cb, FileChooserParams params) {
                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback = cb;
                try {
                    fileLauncher.launch(params.createIntent());
                } catch (RuntimeException e) {
                    fileCallback = null;
                    return false;
                }
                return true;
            }

            @Override public boolean onConsoleMessage(ConsoleMessage m) {
                Log.d(TAG, m.message() + " (" + m.sourceId() + ":" + m.lineNumber() + ")");
                return true;
            }
        });

        setContentView(web);
        getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
            @Override public void handleOnBackPressed() {
                web.evaluateJavascript("(window.PS&&PS.onBack&&PS.onBack())===true", value -> {
                    if (!"true".equals(value)) moveTaskToBack(true);
                });
            }
        });

        web.loadUrl("file:///android_asset/index.html");

        if (Build.VERSION.SDK_INT >= 33
                && ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS);
        }
        if (savedInstanceState == null && ctl.setting("autoStart", false) && !ctl.isRunning()) {
            ContextCompat.startForegroundService(this, new Intent(this, PeerService.class).setAction(PeerService.ACTION_START));
        }
    }

    private void handlePermissionRequest(PermissionRequest request) {
        List<String> need = new ArrayList<>();
        for (String r : request.getResources()) {
            if (PermissionRequest.RESOURCE_VIDEO_CAPTURE.equals(r)) need.add(Manifest.permission.CAMERA);
            else if (PermissionRequest.RESOURCE_AUDIO_CAPTURE.equals(r)) need.add(Manifest.permission.RECORD_AUDIO);
        }
        List<String> missing = new ArrayList<>();
        for (String p : need) {
            if (ContextCompat.checkSelfPermission(this, p) != PackageManager.PERMISSION_GRANTED) missing.add(p);
        }
        if (missing.isEmpty()) {
            request.grant(request.getResources());
        } else {
            if (pendingRequest != null) pendingRequest.deny();
            pendingRequest = request;
            permLauncher.launch(missing.toArray(new String[0]));
        }
    }

    @Override public void onEvent(String type, String json) {
        final String js = "window.PS&&PS.onNative(" + JSONObject.quote(type) + "," + json + ")";
        runOnUiThread(() -> { if (web != null) web.evaluateJavascript(js, null); });
    }

    @Override protected void onResume() {
        super.onResume();
        web.onResume();
        ServerController.get().addListener(this);
        web.evaluateJavascript("window.PS&&PS.refresh&&PS.refresh()", null);
    }

    @Override protected void onPause() {
        // Keep JS (hub peer, heartbeats) running in the background while something needs it.
        if (!hubActive && !ServerController.get().isRunning()) web.onPause();
        super.onPause();
    }

    @Override protected void onStop() {
        ServerController.get().removeListener(this);
        super.onStop();
    }

    @Override protected void onDestroy() {
        ServerController.get().removeListener(this);
        if (fileCallback != null) { fileCallback.onReceiveValue(null); fileCallback = null; }
        if (web != null) { web.destroy(); web = null; }
        super.onDestroy();
    }
}
