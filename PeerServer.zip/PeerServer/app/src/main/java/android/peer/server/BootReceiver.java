package android.peer.server;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

import androidx.core.content.ContextCompat;

/** Starts the server after a reboot when the user enabled "Start on boot". */
public class BootReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context, Intent intent) {
        if (!Intent.ACTION_BOOT_COMPLETED.equals(intent.getAction())) return;
        ServerController.get().init(context);
        if (ServerController.get().setting("startOnBoot", false)) {
            ContextCompat.startForegroundService(context,
                    new Intent(context, PeerService.class).setAction(PeerService.ACTION_START));
        }
    }
}
