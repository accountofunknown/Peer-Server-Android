package android.peer.server;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.graphics.drawable.Icon;
import android.net.wifi.WifiManager;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import android.peer.server.core.ServerConfig;

import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Foreground service that keeps the signalling server alive while the app is in the background. */
public class PeerService extends Service implements ServerController.UiListener {

    public static final String ACTION_START = "android.peer.server.action.START";
    public static final String ACTION_STOP = "android.peer.server.action.STOP";
    private static final String CHANNEL = "peer_server";
    private static final int NOTIF_ID = 1;

    private final ExecutorService exec = Executors.newSingleThreadExecutor();
    private final Handler main = new Handler(Looper.getMainLooper());
    private PowerManager.WakeLock wake;
    private WifiManager.WifiLock wifi;
    private ServerController ctl;

    @Override public void onCreate() {
        super.onCreate();
        ctl = ServerController.get();
        ctl.init(this);
        NotificationChannel ch = new NotificationChannel(CHANNEL, "Server status", NotificationManager.IMPORTANCE_LOW);
        ch.setDescription("Shown while the Peer Server is running");
        ch.setShowBadge(false);
        getSystemService(NotificationManager.class).createNotificationChannel(ch);
        ctl.addListener(this);
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        String action = intent == null ? ACTION_START : intent.getAction();
        startForegroundCompat(buildNotification());
        if (ACTION_STOP.equals(action)) {
            exec.execute(new Runnable() {
                @Override public void run() {
                    ctl.stopEngine(true);
                    main.post(new Runnable() {
                        @Override public void run() { stopForeground(true); stopSelf(); }
                    });
                }
            });
            return START_NOT_STICKY;
        }
        if (intent == null && !ctl.wasRunning()) {
            stopForeground(true);
            stopSelf();
            return START_NOT_STICKY;
        }
        acquireLocks();
        exec.execute(new Runnable() {
            @Override public void run() {
                String err = ctl.startEngine();
                if (!err.isEmpty()) {
                    main.post(new Runnable() {
                        @Override public void run() { stopForeground(true); stopSelf(); }
                    });
                }
            }
        });
        return START_STICKY;
    }

    @Override public void onEvent(String type, String json) {
        if ("state".equals(type)) {
            NotificationManager nm = getSystemService(NotificationManager.class);
            if (nm != null) nm.notify(NOTIF_ID, buildNotification());
        }
    }

    private void startForegroundCompat(Notification n) {
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
        } else {
            startForeground(NOTIF_ID, n);
        }
    }

    private Notification buildNotification() {
        ServerConfig cfg = ctl.config();
        String text;
        if (ctl.isRunning()) {
            String host = "this device";
            List<Object> addr = android.peer.server.core.PeerEngine.lanAddresses();
            if (!addr.isEmpty() && addr.get(0) instanceof Map) {
                Object ip = ((Map<?, ?>) addr.get(0)).get("ip");
                if (ip != null) host = String.valueOf(ip);
            }
            int n = ctl.peerCount();
            text = host + ":" + cfg.port + cfg.normalizedPath() + "  \u00b7  " + n + (n == 1 ? " peer" : " peers");
        } else {
            text = "Starting\u2026";
        }
        Intent open = new Intent(this, MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent openPi = PendingIntent.getActivity(this, 0, open, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        Intent stop = new Intent(this, PeerService.class).setAction(ACTION_STOP);
        PendingIntent stopPi = PendingIntent.getService(this, 1, stop, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        Notification.Builder b = new Notification.Builder(this, CHANNEL)
                .setSmallIcon(R.drawable.ic_stat)
                .setContentTitle("Peer Server")
                .setContentText(text)
                .setContentIntent(openPi)
                .setOngoing(true)
                .setOnlyAlertOnce(true)
                .setCategory(Notification.CATEGORY_SERVICE)
                .addAction(new Notification.Action.Builder(Icon.createWithResource(this, R.drawable.ic_stat), "Stop", stopPi).build());
        if (Build.VERSION.SDK_INT >= 31) b.setForegroundServiceBehavior(Notification.FOREGROUND_SERVICE_IMMEDIATE);
        return b.build();
    }

    @SuppressWarnings("deprecation")
    private void acquireLocks() {
        if (wake == null) {
            PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
            wake = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "PeerServer:server");
            wake.setReferenceCounted(false);
        }
        if (!wake.isHeld()) wake.acquire();
        if (wifi == null) {
            WifiManager wm = (WifiManager) getApplicationContext().getSystemService(Context.WIFI_SERVICE);
            if (wm != null) {
                int mode = Build.VERSION.SDK_INT >= 29 ? WifiManager.WIFI_MODE_FULL_LOW_LATENCY : WifiManager.WIFI_MODE_FULL_HIGH_PERF;
                wifi = wm.createWifiLock(mode, "PeerServer:wifi");
                wifi.setReferenceCounted(false);
            }
        }
        if (wifi != null && !wifi.isHeld()) wifi.acquire();
    }

    private void releaseLocks() {
        if (wake != null && wake.isHeld()) wake.release();
        if (wifi != null && wifi.isHeld()) wifi.release();
    }

    @Override public void onDestroy() {
        ctl.removeListener(this);
        releaseLocks();
        if (ctl.isRunning()) {
            // Stop sockets off the main thread (network I/O is not allowed here).
            new Thread(new Runnable() {
                @Override public void run() { ctl.stopEngine(false); }
            }, "peer-stop").start();
        }
        exec.shutdown();
        super.onDestroy();
    }

    @Override public IBinder onBind(Intent intent) { return null; }
}
