package android.peer.server.core;

import java.io.BufferedInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.EOFException;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.NetworkInterface;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Collection;
import java.util.Collections;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.RejectedExecutionException;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicLong;

/**
 * A PeerJS-protocol compatible signalling server (the same wire protocol as the
 * peerjs-server npm package): HTTP + WebSocket on one port, no external dependencies.
 */
public final class PeerEngine {

    public interface Listener {
        void onLog(String level, String message);
        void onPeersChanged();
        void onTraffic(String type, String src, String dst);
    }

    private static final String WS_GUID = "258EAFA5-E914-47DA-95CA-C5AB0DC85B11";
    private static final int MAX_FRAME = 1 << 20;
    private static final int MAX_QUEUE = 100;

    private final ServerConfig cfg;
    private final Listener listener;
    private final ConcurrentHashMap<String, Client> clients = new ConcurrentHashMap<>();
    private final ConcurrentHashMap<String, List<Queued>> queues = new ConcurrentHashMap<>();
    private final Set<String> blocked = ConcurrentHashMap.newKeySet();
    private final Object registerLock = new Object();
    private final SecureRandom rnd = new SecureRandom();

    private volatile ServerSocket server;
    private volatile boolean running;
    private volatile long startedAt;
    private ExecutorService pool;
    private ScheduledExecutorService sched;

    private final AtomicLong sMessages = new AtomicLong(), sOffers = new AtomicLong(), sAnswers = new AtomicLong(),
            sCandidates = new AtomicLong(), sLeaves = new AtomicLong(), sExpires = new AtomicLong(),
            sHeartbeats = new AtomicLong(), sRelayed = new AtomicLong(), sQueued = new AtomicLong(),
            sRejected = new AtomicLong(), sInvalid = new AtomicLong(), sHttp = new AtomicLong(),
            sBytesIn = new AtomicLong(), sBytesOut = new AtomicLong(), sConnections = new AtomicLong();

    public PeerEngine(ServerConfig cfg, Listener listener) {
        this.cfg = cfg;
        this.listener = listener;
    }

    // ------------------------------------------------------------------ lifecycle

    public synchronized void start() throws IOException {
        if (running) return;
        ServerSocket ss = new ServerSocket();
        ss.setReuseAddress(true);
        ss.bind(new InetSocketAddress(InetAddress.getByName(cfg.bindAddress), cfg.port), 128);
        server = ss;
        running = true;
        startedAt = System.currentTimeMillis();
        pool = Executors.newCachedThreadPool(daemonFactory("peer-io"));
        sched = Executors.newScheduledThreadPool(2, daemonFactory("peer-sched"));
        sched.scheduleWithFixedDelay(this::sweepExpired, 1000, 1000, TimeUnit.MILLISECONDS);
        long aliveEvery = Math.max(1000, Math.min(cfg.aliveTimeout / 4, 5000));
        sched.scheduleWithFixedDelay(this::sweepAlive, aliveEvery, aliveEvery, TimeUnit.MILLISECONDS);
        pool.execute(this::acceptLoop);
        log("info", "Server listening on " + cfg.bindAddress + ":" + cfg.port + " (path " + cfg.normalizedPath() + ", key '" + cfg.key + "')");
    }

    public synchronized void stop() {
        if (!running) return;
        running = false;
        try { server.close(); } catch (IOException ignored) { }
        for (Client c : new ArrayList<>(clients.values())) {
            WsConn s = c.socket;
            if (s != null) { s.close(1001, "Server shutting down"); s.kill(); }
        }
        clients.clear();
        queues.clear();
        pool.shutdownNow();
        sched.shutdownNow();
        log("info", "Server stopped");
        listener.onPeersChanged();
    }

    public boolean isRunning() { return running; }

    public ServerConfig config() { return cfg; }

    private static java.util.concurrent.ThreadFactory daemonFactory(String name) {
        final java.util.concurrent.atomic.AtomicInteger n = new java.util.concurrent.atomic.AtomicInteger();
        return r -> {
            Thread t = new Thread(r, name + "-" + n.incrementAndGet());
            t.setDaemon(true);
            return t;
        };
    }

    private void log(String level, String msg) {
        try { listener.onLog(level, msg); } catch (RuntimeException ignored) { }
    }

    private void changed() {
        try { listener.onPeersChanged(); } catch (RuntimeException ignored) { }
    }

    // ------------------------------------------------------------------ admin API

    public boolean kick(String id) {
        Client c = clients.get(id);
        if (c == null) return false;
        WsConn s = c.socket;
        if (s != null) s.close(1008, "Kicked by server");
        removeClient(c, "kicked");
        return true;
    }

    public int kickAll() {
        int n = 0;
        for (String id : new ArrayList<>(clients.keySet())) if (kick(id)) n++;
        return n;
    }

    public void setBlocked(Collection<String> ips) {
        blocked.clear();
        if (ips != null) blocked.addAll(ips);
    }

    public void block(String ip) {
        blocked.add(ip);
        for (Client c : new ArrayList<>(clients.values())) if (ip.equals(c.ip)) kick(c.id);
    }

    public void unblock(String ip) { blocked.remove(ip); }

    public List<String> blockedList() {
        List<String> l = new ArrayList<>(blocked);
        Collections.sort(l);
        return l;
    }

    public Map<String, Object> snapshot() {
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("running", running);
        m.put("startedAt", startedAt);
        m.put("config", cfg.toMap());
        List<Object> peers = new ArrayList<>();
        List<Client> list = new ArrayList<>(clients.values());
        Collections.sort(list, (a, b) -> Long.compare(a.connectedAt, b.connectedAt));
        for (Client c : list) {
            Map<String, Object> p = new LinkedHashMap<>();
            p.put("id", c.id);
            p.put("ip", c.ip);
            p.put("connectedAt", c.connectedAt);
            p.put("lastPing", c.lastPing);
            p.put("in", c.in.get());
            p.put("out", c.out.get());
            p.put("ua", c.ua == null ? "" : c.ua);
            peers.add(p);
        }
        m.put("peers", peers);
        long queued = 0;
        for (List<Queued> q : queues.values()) queued += q.size();
        m.put("queued", queued);
        Map<String, Object> st = new LinkedHashMap<>();
        st.put("messages", sMessages.get());
        st.put("offers", sOffers.get());
        st.put("answers", sAnswers.get());
        st.put("candidates", sCandidates.get());
        st.put("leaves", sLeaves.get());
        st.put("expires", sExpires.get());
        st.put("heartbeats", sHeartbeats.get());
        st.put("relayed", sRelayed.get());
        st.put("queuedTotal", sQueued.get());
        st.put("rejected", sRejected.get());
        st.put("invalid", sInvalid.get());
        st.put("http", sHttp.get());
        st.put("bytesIn", sBytesIn.get());
        st.put("bytesOut", sBytesOut.get());
        st.put("connections", sConnections.get());
        m.put("stats", st);
        m.put("blocked", blockedList());
        return m;
    }

    public static List<Object> lanAddresses() {
        List<Object> out = new ArrayList<>();
        try {
            Enumeration<NetworkInterface> en = NetworkInterface.getNetworkInterfaces();
            while (en != null && en.hasMoreElements()) {
                NetworkInterface ni = en.nextElement();
                if (!ni.isUp() || ni.isLoopback()) continue;
                Enumeration<InetAddress> ad = ni.getInetAddresses();
                while (ad.hasMoreElements()) {
                    InetAddress a = ad.nextElement();
                    if (a.isLoopbackAddress() || a.isLinkLocalAddress() || a.getHostAddress().indexOf(':') >= 0) continue;
                    Map<String, Object> e = new LinkedHashMap<>();
                    e.put("iface", ni.getDisplayName());
                    e.put("ip", a.getHostAddress());
                    out.add(e);
                }
            }
        } catch (Exception ignored) { }
        return out;
    }

    // ------------------------------------------------------------------ models

    private static final class Client {
        final String id, token, ip;
        final long connectedAt = System.currentTimeMillis();
        volatile long lastPing = connectedAt;
        volatile WsConn socket;
        volatile String ua;
        final AtomicLong in = new AtomicLong(), out = new AtomicLong();

        Client(String id, String token, String ip) { this.id = id; this.token = token; this.ip = ip; }
    }

    private static final class Queued {
        final Map<String, Object> msg;
        final long at = System.currentTimeMillis();
        Queued(Map<String, Object> msg) { this.msg = msg; }
    }

    /** One websocket connection; frames are written whole under a lock. */
    private final class WsConn {
        final Socket sock;
        final OutputStream out;
        volatile boolean open = true;

        WsConn(Socket sock, OutputStream out) { this.sock = sock; this.out = out; }

        boolean sendText(String s) {
            byte[] p = s.getBytes(StandardCharsets.UTF_8);
            synchronized (this) {
                if (!open) return false;
                try {
                    writeFrame(0x1, p);
                    sBytesOut.addAndGet(p.length);
                    return true;
                } catch (IOException e) {
                    open = false;
                    kill();
                    return false;
                }
            }
        }

        synchronized void writeFrame(int op, byte[] p) throws IOException {
            ByteArrayOutputStream b = new ByteArrayOutputStream(p.length + 10);
            b.write(0x80 | op);
            if (p.length < 126) b.write(p.length);
            else if (p.length <= 0xFFFF) { b.write(126); b.write(p.length >> 8); b.write(p.length); }
            else {
                b.write(127);
                for (int k = 7; k >= 0; k--) b.write((int) (((long) p.length >> (8 * k)) & 0xFF));
            }
            b.write(p);
            out.write(b.toByteArray());
            out.flush();
        }

        void close(int code, String reason) {
            synchronized (this) {
                if (!open) return;
                open = false;
                try {
                    byte[] r = reason.getBytes(StandardCharsets.UTF_8);
                    byte[] p = new byte[2 + r.length];
                    p[0] = (byte) (code >> 8);
                    p[1] = (byte) code;
                    System.arraycopy(r, 0, p, 2, r.length);
                    writeFrame(0x8, p);
                    sock.shutdownOutput();
                } catch (IOException ignored) { }
            }
            try { sched.schedule(this::kill, 1, TimeUnit.SECONDS); } catch (RuntimeException ignored) { kill(); }
        }

        void kill() {
            open = false;
            try { sock.close(); } catch (IOException ignored) { }
        }
    }

    // ------------------------------------------------------------------ accept + HTTP

    private void acceptLoop() {
        ServerSocket ss = server;
        while (running && ss != null && !ss.isClosed()) {
            try {
                final Socket s = ss.accept();
                pool.execute(() -> handle(s));
            } catch (IOException e) {
                if (!running) break;
                log("warn", "Accept error: " + e.getMessage());
                try { Thread.sleep(100); } catch (InterruptedException ie) { break; }
            } catch (RejectedExecutionException e) {
                break;
            }
        }
    }

    private void handle(Socket s) {
        boolean keep = false;
        boolean failed = false;
        try {
            s.setTcpNoDelay(true);
            s.setSoTimeout(15000);
            InputStream in = new BufferedInputStream(s.getInputStream(), 8192);
            OutputStream out = s.getOutputStream();
            String line = readLine(in);
            if (line == null || line.isEmpty()) return;
            String[] parts = line.split(" ");
            if (parts.length < 3) { respond(out, 400, "application/json", "{\"msg\":\"Bad request\"}"); return; }
            String method = parts[0].toUpperCase(Locale.ROOT);
            String target = parts[1];
            Map<String, String> headers = new HashMap<>();
            for (int n = 0; n < 100; n++) {
                String h = readLine(in);
                if (h == null) return;
                if (h.isEmpty()) break;
                int c = h.indexOf(':');
                if (c > 0) headers.put(h.substring(0, c).trim().toLowerCase(Locale.ROOT), h.substring(c + 1).trim());
            }
            String ip = s.getInetAddress().getHostAddress();
            if (cfg.proxied && headers.containsKey("x-forwarded-for")) {
                ip = headers.get("x-forwarded-for").split(",")[0].trim();
            }
            if (blocked.contains(ip)) {
                sRejected.incrementAndGet();
                respond(out, 403, "application/json", "{\"msg\":\"Blocked\"}");
                return;
            }
            String path = target, query = "";
            int qi = target.indexOf('?');
            if (qi >= 0) { path = target.substring(0, qi); query = target.substring(qi + 1); }
            Map<String, String> q = parseQuery(query);
            String base = cfg.normalizedPath();
            String wsPath = base + "peerjs";
            boolean upgrade = "websocket".equalsIgnoreCase(headers.get("upgrade"));
            if (upgrade) {
                if (path.equals(wsPath) || path.equals(wsPath + "/")) {
                    keep = true;
                    webSocket(s, in, out, headers, q, ip);
                } else {
                    respond(out, 404, "application/json", "{\"msg\":\"Not found\"}");
                }
                return;
            }
            sHttp.incrementAndGet();
            http(method, path, base, headers, in, out);
        } catch (EOFException | java.net.SocketTimeoutException ignored) {
            failed = true;
        } catch (Exception e) {
            failed = true;
            if (running) log("warn", "Connection error: " + e);
        } finally {
            if (!keep || failed) { try { s.close(); } catch (IOException ignored) { } }
        }
    }

    private void http(String method, String path, String base, Map<String, String> headers,
                      InputStream in, OutputStream out) throws IOException {
        if (method.equals("OPTIONS")) { respond(out, 204, "text/plain", ""); return; }
        String rest;
        if (path.startsWith(base)) rest = path.substring(base.length());
        else if ((path + "/").equals(base)) rest = "";
        else { respond(out, 404, "application/json", "{\"msg\":\"Not found\"}"); return; }
        while (rest.endsWith("/")) rest = rest.substring(0, rest.length() - 1);
        String[] seg = rest.isEmpty() ? new String[0] : rest.split("/");

        if (seg.length == 0 && method.equals("GET")) {
            Map<String, Object> info = new LinkedHashMap<>();
            info.put("name", "PeerJS Server");
            info.put("description", "A server side element to broker connections between PeerJS clients.");
            info.put("website", "https://peerjs.com/");
            respond(out, 200, "application/json", Json.stringify(info));
            return;
        }
        if (seg.length == 2 && method.equals("GET") && (seg[1].equals("id") || seg[1].equals("peers"))) {
            if (!seg[0].equals(cfg.key)) { respond(out, 401, "application/json", "{\"msg\":\"Invalid key provided\"}"); return; }
            if (seg[1].equals("id")) { respond(out, 200, "text/html; charset=utf-8", generateId()); return; }
            if (!cfg.allowDiscovery) { respond(out, 401, "text/plain", "Unauthorized"); return; }
            List<String> ids = new ArrayList<>(clients.keySet());
            Collections.sort(ids);
            respond(out, 200, "application/json", Json.stringify(ids));
            return;
        }
        if (seg.length == 4 && method.equals("POST")) {
            String t = seg[3].toLowerCase(Locale.ROOT);
            if (!(t.equals("offer") || t.equals("answer") || t.equals("candidate") || t.equals("leave"))) {
                respond(out, 404, "application/json", "{\"msg\":\"Not found\"}");
                return;
            }
            if (!seg[0].equals(cfg.key)) { respond(out, 401, "application/json", "{\"msg\":\"Invalid key provided\"}"); return; }
            Client c = clients.get(seg[1]);
            if (c == null || !c.token.equals(seg[2])) { respond(out, 401, "application/json", "{\"msg\":\"Invalid token provided\"}"); return; }
            int len = 0;
            try { len = Integer.parseInt(headers.getOrDefault("content-length", "0")); } catch (NumberFormatException ignored) { }
            if (len < 0 || len > MAX_FRAME) { respond(out, 413, "application/json", "{\"msg\":\"Too large\"}"); return; }
            byte[] body = new byte[len];
            new DataInputStream(in).readFully(body);
            try {
                Map<String, Object> msg = Json.parseObject(new String(body, StandardCharsets.UTF_8));
                msg.put("type", t.toUpperCase(Locale.ROOT));
                msg.put("src", c.id);
                c.lastPing = System.currentTimeMillis();
                c.in.incrementAndGet();
                countMessage(msg);
                transmit(msg);
                respond(out, 200, "text/plain", "OK");
            } catch (IllegalArgumentException e) {
                sInvalid.incrementAndGet();
                respond(out, 400, "application/json", "{\"msg\":\"Invalid JSON\"}");
            }
            return;
        }
        respond(out, 404, "application/json", "{\"msg\":\"Not found\"}");
    }

    private void respond(OutputStream out, int status, String type, String body) throws IOException {
        byte[] b = body.getBytes(StandardCharsets.UTF_8);
        String reason;
        switch (status) {
            case 200: reason = "OK"; break;
            case 204: reason = "No Content"; break;
            case 400: reason = "Bad Request"; break;
            case 401: reason = "Unauthorized"; break;
            case 403: reason = "Forbidden"; break;
            case 404: reason = "Not Found"; break;
            case 413: reason = "Payload Too Large"; break;
            default: reason = "OK";
        }
        StringBuilder h = new StringBuilder();
        h.append("HTTP/1.1 ").append(status).append(' ').append(reason).append("\r\n");
        h.append("Content-Type: ").append(type).append("\r\n");
        h.append("Content-Length: ").append(b.length).append("\r\n");
        h.append("Access-Control-Allow-Origin: ").append(cfg.corsOrigin).append("\r\n");
        h.append("Access-Control-Allow-Methods: GET, POST, OPTIONS\r\n");
        h.append("Access-Control-Allow-Headers: *\r\n");
        h.append("Access-Control-Allow-Private-Network: true\r\n");
        h.append("Cache-Control: no-store\r\n");
        h.append("Connection: close\r\n\r\n");
        ByteArrayOutputStream o = new ByteArrayOutputStream();
        o.write(h.toString().getBytes(StandardCharsets.UTF_8));
        o.write(b);
        out.write(o.toByteArray());
        out.flush();
    }

    private static String readLine(InputStream in) throws IOException {
        StringBuilder sb = new StringBuilder();
        while (true) {
            int c = in.read();
            if (c < 0) return sb.length() == 0 ? null : sb.toString();
            if (c == '\n') {
                int n = sb.length();
                if (n > 0 && sb.charAt(n - 1) == '\r') sb.setLength(n - 1);
                return sb.toString();
            }
            sb.append((char) c);
            if (sb.length() > 8192) throw new IOException("Header line too long");
        }
    }

    private static Map<String, String> parseQuery(String q) {
        Map<String, String> m = new HashMap<>();
        if (q == null || q.isEmpty()) return m;
        for (String pair : q.split("&")) {
            if (pair.isEmpty()) continue;
            int e = pair.indexOf('=');
            try {
                String k = URLDecoder.decode(e < 0 ? pair : pair.substring(0, e), "UTF-8");
                String v = e < 0 ? "" : URLDecoder.decode(pair.substring(e + 1), "UTF-8");
                m.put(k, v);
            } catch (Exception ignored) { }
        }
        return m;
    }

    // ------------------------------------------------------------------ websocket session

    private void webSocket(Socket s, InputStream in, OutputStream out, Map<String, String> headers,
                           Map<String, String> q, String ip) throws Exception {
        String wkey = headers.get("sec-websocket-key");
        if (wkey == null) { respond(out, 400, "application/json", "{\"msg\":\"Missing Sec-WebSocket-Key\"}"); s.close(); return; }
        String accept = Base64.getEncoder().encodeToString(
                MessageDigest.getInstance("SHA-1").digest((wkey + WS_GUID).getBytes(StandardCharsets.US_ASCII)));
        out.write(("HTTP/1.1 101 Switching Protocols\r\nUpgrade: websocket\r\nConnection: Upgrade\r\n"
                + "Sec-WebSocket-Accept: " + accept + "\r\n\r\n").getBytes(StandardCharsets.US_ASCII));
        out.flush();
        s.setSoTimeout(0);
        s.setKeepAlive(true);
        final WsConn c = new WsConn(s, out);
        String id = q.get("id"), token = q.get("token"), key = q.get("key");

        if (isEmpty(id) || isEmpty(token) || isEmpty(key)) {
            sRejected.incrementAndGet();
            errorAndClose(c, "No id, token, or key supplied to websocket server");
            return;
        }
        if (!key.equals(cfg.key)) {
            sRejected.incrementAndGet();
            log("warn", "Rejected '" + id + "' from " + ip + ": invalid key");
            errorAndClose(c, "Invalid key provided");
            return;
        }
        final Client client;
        synchronized (registerLock) {
            Client ex = clients.get(id);
            if (ex != null) {
                if (!token.equals(ex.token)) {
                    sRejected.incrementAndGet();
                    log("warn", "ID '" + id + "' is taken (rejected " + ip + ")");
                    c.sendText("{\"type\":\"ID-TAKEN\",\"payload\":{\"msg\":\"ID is taken\"}}");
                    c.close(1008, "ID is taken");
                    return;
                }
                WsConn old = ex.socket;
                ex.socket = c;
                ex.lastPing = System.currentTimeMillis();
                client = ex;
                if (old != null && old != c) old.close(1000, "Replaced by new connection");
            } else {
                if (clients.size() >= cfg.concurrentLimit) {
                    sRejected.incrementAndGet();
                    log("warn", "Rejected '" + id + "': concurrent limit reached");
                    errorAndClose(c, "Server has reached its concurrent user limit");
                    return;
                }
                client = new Client(id, token, ip);
                client.socket = c;
                clients.put(id, client);
            }
        }
        client.ua = headers.get("user-agent");
        sConnections.incrementAndGet();
        c.sendText("{\"type\":\"OPEN\"}");
        log("info", "Peer connected: " + id + " (" + ip + ")");
        changed();
        flushQueue(client);

        try {
            while (running && c.open) {
                String msg = readMessage(in, c);
                if (msg == null) break;
                onClientMessage(client, msg);
            }
        } catch (IOException | RuntimeException e) {
            // connection dropped
        } finally {
            c.open = false;
            c.kill();
            if (client.socket == c) removeClient(client, "disconnected");
        }
    }

    private static boolean isEmpty(String s) { return s == null || s.isEmpty(); }

    private void errorAndClose(WsConn c, String msg) {
        Map<String, Object> payload = new LinkedHashMap<>();
        payload.put("msg", msg);
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("type", "ERROR");
        m.put("payload", payload);
        c.sendText(Json.stringify(m));
        c.close(1008, msg.length() > 100 ? msg.substring(0, 100) : msg);
    }

    /** Returns the next complete text message, or null when the peer closed. */
    private String readMessage(InputStream in, WsConn c) throws IOException {
        DataInputStream d = new DataInputStream(in);
        ByteArrayOutputStream acc = null;
        boolean textMsg = false;
        while (true) {
            int b0 = d.readUnsignedByte();
            int b1 = d.readUnsignedByte();
            boolean fin = (b0 & 0x80) != 0;
            int op = b0 & 0x0F;
            boolean masked = (b1 & 0x80) != 0;
            long len = b1 & 0x7F;
            if (len == 126) len = d.readUnsignedShort();
            else if (len == 127) len = d.readLong();
            if (len < 0 || len > MAX_FRAME) { c.close(1009, "Message too big"); return null; }
            byte[] mask = null;
            if (masked) { mask = new byte[4]; d.readFully(mask); }
            byte[] p = new byte[(int) len];
            d.readFully(p);
            if (masked) for (int k = 0; k < p.length; k++) p[k] ^= mask[k & 3];
            sBytesIn.addAndGet(p.length);
            switch (op) {
                case 0x8: c.close(1000, ""); return null;
                case 0x9:
                    synchronized (c) { try { c.writeFrame(0xA, p); } catch (IOException e) { return null; } }
                    break;
                case 0xA: break;
                case 0x1: case 0x2: case 0x0:
                    if (op != 0x0) { acc = new ByteArrayOutputStream(); textMsg = (op == 0x1); }
                    if (acc == null) break;
                    if (acc.size() + p.length > MAX_FRAME) { c.close(1009, "Message too big"); return null; }
                    acc.write(p);
                    if (fin) {
                        String r = textMsg ? new String(acc.toByteArray(), StandardCharsets.UTF_8) : "";
                        acc = null;
                        if (textMsg) return r;
                    }
                    break;
                default: break;
            }
        }
    }

    // ------------------------------------------------------------------ message handling

    private void onClientMessage(Client client, String raw) {
        client.in.incrementAndGet();
        Map<String, Object> msg;
        try {
            msg = Json.parseObject(raw);
        } catch (RuntimeException e) {
            sInvalid.incrementAndGet();
            log("warn", "Invalid JSON from " + client.id);
            return;
        }
        msg.put("src", client.id);
        String type = Json.str(msg, "type", "");
        if (type.equals("HEARTBEAT")) {
            client.lastPing = System.currentTimeMillis();
            sHeartbeats.incrementAndGet();
            return;
        }
        if (type.equals("OFFER") || type.equals("ANSWER") || type.equals("CANDIDATE")
                || type.equals("LEAVE") || type.equals("EXPIRE")) {
            countMessage(msg);
            transmit(msg);
        } else {
            sInvalid.incrementAndGet();
        }
    }

    private void countMessage(Map<String, Object> msg) {
        sMessages.incrementAndGet();
        switch (Json.str(msg, "type", "")) {
            case "OFFER": sOffers.incrementAndGet(); break;
            case "ANSWER": sAnswers.incrementAndGet(); break;
            case "CANDIDATE": sCandidates.incrementAndGet(); break;
            case "LEAVE": sLeaves.incrementAndGet(); break;
            case "EXPIRE": sExpires.incrementAndGet(); break;
            default: break;
        }
    }

    private void transmit(Map<String, Object> msg) {
        String type = Json.str(msg, "type", "");
        String src = Json.str(msg, "src", null);
        String dst = Json.str(msg, "dst", null);
        try { listener.onTraffic(type, src, dst); } catch (RuntimeException ignored) { }
        Client d = dst == null ? null : clients.get(dst);
        if (d != null) {
            WsConn sock = d.socket;
            boolean ok = sock != null && sock.sendText(Json.stringify(msg));
            if (ok) {
                d.out.incrementAndGet();
                sRelayed.incrementAndGet();
            } else {
                if (sock != null) sock.close(1011, "Peer dead");
                removeClient(d, "dead socket");
                Map<String, Object> leave = new LinkedHashMap<>();
                leave.put("type", "LEAVE");
                leave.put("src", dst);
                leave.put("dst", src);
                transmit(leave);
            }
        } else if (dst != null && !type.equals("LEAVE") && !type.equals("EXPIRE")) {
            List<Queued> q = queues.computeIfAbsent(dst, k -> new CopyOnWriteArrayList<>());
            if (q.size() >= MAX_QUEUE) q.remove(0);
            q.add(new Queued(msg));
            sQueued.incrementAndGet();
        } else if (type.equals("LEAVE") && dst == null && src != null) {
            Client c = clients.get(src);
            if (c != null) {
                WsConn sock = c.socket;
                removeClient(c, "left");
                if (sock != null) sock.close(1000, "Left");
            }
        }
    }

    private void flushQueue(Client client) {
        List<Queued> q = queues.remove(client.id);
        if (q == null) return;
        for (Queued m : q) transmit(m.msg);
    }

    private void removeClient(Client c, String reason) {
        if (clients.remove(c.id, c)) {
            log("info", "Peer left: " + c.id + " (" + reason + ")");
            changed();
        }
    }

    private void sweepExpired() {
        try {
            long now = System.currentTimeMillis();
            for (Map.Entry<String, List<Queued>> e : queues.entrySet()) {
                List<Queued> list = e.getValue();
                Set<String> seen = new HashSet<>();
                List<Queued> dead = new ArrayList<>();
                for (Queued m : list) if (now - m.at > cfg.expireTimeout) dead.add(m);
                if (dead.isEmpty()) continue;
                list.removeAll(dead);
                if (list.isEmpty()) queues.remove(e.getKey(), list);
                for (Queued m : dead) {
                    String src = Json.str(m.msg, "src", null);
                    if (src == null || !seen.add(src)) continue;
                    Map<String, Object> ex = new LinkedHashMap<>();
                    ex.put("type", "EXPIRE");
                    ex.put("src", e.getKey());
                    ex.put("dst", src);
                    sExpires.incrementAndGet();
                    transmit(ex);
                }
            }
        } catch (RuntimeException ex) {
            log("error", "Expiry sweep failed: " + ex);
        }
    }

    private void sweepAlive() {
        try {
            long now = System.currentTimeMillis();
            for (Client c : new ArrayList<>(clients.values())) {
                if (now - c.lastPing > cfg.aliveTimeout) {
                    WsConn s = c.socket;
                    if (s != null) s.close(1001, "Heartbeat timeout");
                    removeClient(c, "heartbeat timeout");
                }
            }
        } catch (RuntimeException ex) {
            log("error", "Alive sweep failed: " + ex);
        }
    }

    private String generateId() {
        final String alphabet = "abcdefghijklmnopqrstuvwxyz0123456789";
        while (true) {
            StringBuilder b = new StringBuilder(cfg.idPrefix);
            for (int k = 0; k < cfg.idLength; k++) b.append(alphabet.charAt(rnd.nextInt(alphabet.length())));
            String id = b.toString();
            if (!clients.containsKey(id)) return id;
        }
    }
}
