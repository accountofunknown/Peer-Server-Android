package android.peer.server.core;

import java.util.LinkedHashMap;
import java.util.Map;

/** Mirrors the options of the peerjs-server package. */
public final class ServerConfig {
    public int port = 9000;
    public String path = "/";
    public String key = "peerjs";
    public int concurrentLimit = 5000;
    public boolean allowDiscovery = true;
    public long aliveTimeout = 60000;
    public long expireTimeout = 5000;
    public String idPrefix = "";
    public int idLength = 8;
    public String corsOrigin = "*";
    public boolean proxied = false;
    public String bindAddress = "0.0.0.0";

    public String normalizedPath() {
        String p = path == null ? "/" : path.trim();
        if (!p.startsWith("/")) p = "/" + p;
        if (!p.endsWith("/")) p = p + "/";
        return p;
    }

    public static ServerConfig fromJson(String json) {
        ServerConfig c = new ServerConfig();
        try {
            Map<String, Object> o = Json.parseObject(json);
            c.port = clamp((int) Json.num(o, "port", c.port), 1024, 65535);
            c.path = Json.str(o, "path", c.path);
            c.key = Json.str(o, "key", c.key).trim();
            if (c.key.isEmpty()) c.key = "peerjs";
            c.concurrentLimit = (int) Math.max(1, Json.num(o, "concurrentLimit", c.concurrentLimit));
            c.allowDiscovery = Json.bool(o, "allowDiscovery", c.allowDiscovery);
            c.aliveTimeout = Math.max(5000, Json.num(o, "aliveTimeout", c.aliveTimeout));
            c.expireTimeout = Math.max(1000, Json.num(o, "expireTimeout", c.expireTimeout));
            c.idPrefix = Json.str(o, "idPrefix", c.idPrefix).replaceAll("[^A-Za-z0-9_.-]", "");
            c.idLength = clamp((int) Json.num(o, "idLength", c.idLength), 4, 32);
            c.corsOrigin = Json.str(o, "corsOrigin", c.corsOrigin);
            c.proxied = Json.bool(o, "proxied", c.proxied);
        } catch (Exception ignored) { }
        return c;
    }

    public Map<String, Object> toMap() {
        Map<String, Object> o = new LinkedHashMap<>();
        o.put("port", port); o.put("path", path); o.put("key", key);
        o.put("concurrentLimit", concurrentLimit); o.put("allowDiscovery", allowDiscovery);
        o.put("aliveTimeout", aliveTimeout); o.put("expireTimeout", expireTimeout);
        o.put("idPrefix", idPrefix); o.put("idLength", idLength);
        o.put("corsOrigin", corsOrigin); o.put("proxied", proxied);
        return o;
    }

    private static int clamp(int v, int lo, int hi) { return Math.max(lo, Math.min(hi, v)); }
}
