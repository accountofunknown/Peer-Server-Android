package android.peer.server;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Handler;
import android.os.Looper;
import android.peer.server.core.Json;
import android.peer.server.core.PeerEngine;
import android.peer.server.core.ServerConfig;

import java.io.IOException;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.CopyOnWriteArraySet;

/** Process-wide owner of the engine, persisted settings and the UI event fan-out. */
public final class ServerController implements PeerEngine.Listener {

    public interface UiListener { void onEvent(String type, String json); }

    private static final ServerController INSTANCE = new ServerController();
    public static ServerController get() { return INSTANCE; }

    private final Set<UiListener> listeners = new CopyOnWriteArraySet<>();
    private final ArrayDeque<String> logs = new ArrayDeque<>();
    private final ArrayDeque<String> traffic = new ArrayDeque<>();
    private final Handler main = new Handler(Looper.getMainLooper());
    private Context app;
    private SharedPreferences prefs;
    private volatile PeerEngine engine;
    private volatile String lastError = "";
    private boolean pushQueued;

    private ServerController() { }

    public synchronized void init(Context ctx) {
        if (app != null) return;
        app = ctx.getApplicationContext();
        prefs = app.getSharedPreferences("peer_server", Context.MODE_PRIVATE);
    }

    public void addListener(UiListener l) { listeners.add(l); }
    public void removeListener(UiListener l) { listeners.remove(l); }

    private void emit(String type, String json) {
        for (UiListener l : listeners) {
            try { l.onEvent(type, json); } catch (RuntimeException ignored) { }
        }
    }

    // ------------------------------------------------------------ persisted state

    public ServerConfig config() { return ServerConfig.fromJson(prefs.getString("config", "{}")); }

    public void saveConfig(String json) {
        ServerConfig c = ServerConfig.fromJson(json);
        prefs.edit().putString("config", Json.stringify(c.toMap())).apply();
    }

    public String settingsJson() { return prefs.getString("settings", "{}"); }

    public boolean saveSettings(String json) {
        try {
            Json.parseObject(json);
            prefs.edit().putString("settings", json).apply();
            return true;
        } catch (RuntimeException e) {
            return false;
        }
    }

    public boolean setting(String key, boolean def) {
        try { return Json.bool(Json.parseObject(settingsJson()), key, def); } catch (RuntimeException e) { return def; }
    }

    public boolean wasRunning() { return prefs.getBoolean("wasRunning", false); }

    private Set<String> blockedPrefs() { return new HashSet<>(prefs.getStringSet("blocked", new HashSet<String>())); }

    // ------------------------------------------------------------ engine control (call off the main thread)

    public synchronized String startEngine() {
        if (engine != null && engine.isRunning()) return "";
        PeerEngine e = new PeerEngine(config(), this);
        e.setBlocked(blockedPrefs());
        try {
            e.start();
        } catch (IOException ex) {
            lastError = ex.getMessage() == null ? ex.toString() : ex.getMessage();
            addLog("error", "Could not start server: " + lastError);
            prefs.edit().putBoolean("wasRunning", false).apply();
            emit("state", stateJson());
            return lastError;
        }
        engine = e;
        lastError = "";
        prefs.edit().putBoolean("wasRunning", true).apply();
        emit("state", stateJson());
        return "";
    }

    public synchronized void stopEngine(boolean byUser) {
        PeerEngine e = engine;
        if (e != null) e.stop();
        engine = null;
        if (byUser) prefs.edit().putBoolean("wasRunning", false).apply();
        emit("state", stateJson());
    }

    public boolean isRunning() { PeerEngine e = engine; return e != null && e.isRunning(); }

    public boolean kick(String id) { PeerEngine e = engine; return e != null && e.kick(id); }

    public int kickAll() { PeerEngine e = engine; return e == null ? 0 : e.kickAll(); }

    public void block(String ip) {
        Set<String> b = blockedPrefs();
        b.add(ip);
        prefs.edit().putStringSet("blocked", b).apply();
        PeerEngine e = engine;
        if (e != null) e.block(ip);
        addLog("warn", "Blocked IP " + ip);
        schedulePush();
    }

    public void unblock(String ip) {
        Set<String> b = blockedPrefs();
        b.remove(ip);
        prefs.edit().putStringSet("blocked", b).apply();
        PeerEngine e = engine;
        if (e != null) e.unblock(ip);
        addLog("info", "Unblocked IP " + ip);
        schedulePush();
    }

    // ------------------------------------------------------------ JSON for the UI

    public int peerCount() {
        PeerEngine e = engine;
        if (e == null) return 0;
        Object p = e.snapshot().get("peers");
        return p instanceof List ? ((List<?>) p).size() : 0;
    }

    public String stateJson() {
        Map<String, Object> m = new LinkedHashMap<>();
        PeerEngine e = engine;
        Map<String, Object> snap;
        if (e != null) {
            snap = e.snapshot();
        } else {
            snap = new LinkedHashMap<>();
            snap.put("running", false);
            snap.put("startedAt", 0L);
            snap.put("peers", new ArrayList<Object>());
            snap.put("queued", 0L);
            snap.put("stats", new LinkedHashMap<String, Object>());
            snap.put("blocked", new ArrayList<>(new java.util.TreeSet<>(blockedPrefs())));
        }
        m.put("server", snap);
        m.put("config", config().toMap());
        m.put("addresses", PeerEngine.lanAddresses());
        Object settings;
        try { settings = Json.parseObject(settingsJson()); } catch (RuntimeException ex) { settings = new LinkedHashMap<String, Object>(); }
        m.put("settings", settings);
        m.put("error", lastError);
        m.put("now", System.currentTimeMillis());
        return Json.stringify(m);
    }

    public String logsJson() {
        StringBuilder b = new StringBuilder("{\"logs\":[");
        synchronized (logs) {
            boolean first = true;
            for (String s : logs) { if (!first) b.append(','); first = false; b.append(s); }
        }
        b.append("],\"traffic\":[");
        synchronized (traffic) {
            boolean first = true;
            for (String s : traffic) { if (!first) b.append(','); first = false; b.append(s); }
        }
        b.append("]}");
        return b.toString();
    }

    // ------------------------------------------------------------ engine listener

    private void addLog(String level, String msg) {
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("t", System.currentTimeMillis());
        m.put("level", level);
        m.put("msg", msg);
        String j = Json.stringify(m);
        synchronized (logs) {
            logs.addLast(j);
            while (logs.size() > 600) logs.removeFirst();
        }
        emit("log", j);
    }

    @Override public void onLog(String level, String message) { addLog(level, message); }

    @Override public void onPeersChanged() { schedulePush(); }

    @Override public void onTraffic(String type, String src, String dst) {
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("t", System.currentTimeMillis());
        m.put("type", type);
        m.put("src", src);
        m.put("dst", dst);
        String j = Json.stringify(m);
        synchronized (traffic) {
            traffic.addLast(j);
            while (traffic.size() > 400) traffic.removeFirst();
        }
        emit("traffic", j);
    }

    public void schedulePush() {
        synchronized (this) {
            if (pushQueued) return;
            pushQueued = true;
        }
        main.postDelayed(new Runnable() {
            @Override public void run() {
                synchronized (ServerController.this) { pushQueued = false; }
                emit("state", stateJson());
            }
        }, 300);
    }
}
