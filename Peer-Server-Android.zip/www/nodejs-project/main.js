'use strict';

/**
 * Embedded PeerJS PeerServer for Android (nodejs-mobile)
 * Listens on 0.0.0.0:9000 so other devices on the LAN can connect.
 */

const http = require('http');
const { PeerServer } = require('peer');

const PORT = Number(process.env.PEER_SERVER_PORT || 9000);
const PATH = '/peerjs';
const KEY = 'peerjs';

function emit(type, message, extra) {
  try {
    const bridge = require('nodejs-mobile-cordova');
    if (bridge && bridge.channel && typeof bridge.channel.post === 'function') {
      bridge.channel.post('message', Object.assign({ type: type, message: message }, extra || {}));
    }
  } catch (e) {
    // bridge not available in pure Node tests
  }
  console.log('[PeerServer] ' + message);
}

// Create a plain HTTP server that we will attach PeerServer to
const server = http.createServer((req, res) => {
  // Simple health endpoint used by the dashboard
  if (req.url === '/healthz' || req.url === '/health') {
    res.writeHead(200, {
      'Content-Type': 'application/json',
      'Cache-Control': 'no-store',
      'Access-Control-Allow-Origin': '*'
    });
    return res.end(JSON.stringify({
      ok: true,
      service: 'Peer Server',
      port: PORT,
      path: PATH,
      key: KEY,
      time: new Date().toISOString()
    }));
  }

  // CORS preflight for health checks from the WebView
  if (req.method === 'OPTIONS') {
    res.writeHead(204, {
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Methods': 'GET, OPTIONS',
      'Access-Control-Allow-Headers': 'Content-Type'
    });
    return res.end();
  }

  res.writeHead(404, { 'Content-Type': 'application/json' });
  res.end(JSON.stringify({ error: 'Not found' }));
});

// Attach the real PeerServer to the same HTTP server
const peerServer = PeerServer({
  server: server,
  path: PATH,
  key: KEY,
  allow_discovery: true,
  expire_timeout: 5000,
  alive_timeout: 60000,
  concurrent_limit: 5000,
  proxied: false
});

peerServer.on('connection', function (client) {
  emit('log', 'Peer connected: ' + client.getId(), { peerId: client.getId() });
});

peerServer.on('disconnect', function (client) {
  emit('log', 'Peer disconnected: ' + client.getId(), { peerId: client.getId() });
});

// Bind to all interfaces so LAN clients can reach the phone
server.listen(PORT, '0.0.0.0', function () {
  emit('status', 'PeerServer listening on 0.0.0.0:' + PORT + PATH, {
    online: true,
    port: PORT,
    path: PATH,
    key: KEY
  });
  console.log('PeerServer ready → http://0.0.0.0:' + PORT + PATH);
});

process.on('uncaughtException', function (err) {
  emit('log', 'Uncaught exception: ' + (err && err.message ? err.message : String(err)));
});

process.on('unhandledRejection', function (reason) {
  emit('log', 'Unhandled rejection: ' + String(reason));
});
