'use strict';
const http = require('http');
const os = require('os');
const { PeerServer } = require('peer');

const PORT = Number(process.env.PEER_SERVER_PORT || 9000);
const PATH = '/peerjs';
const KEY = 'peerjs';
const server = http.createServer((req, res) => {
  if (req.url === '/healthz') {
    res.writeHead(200, {'content-type':'application/json','cache-control':'no-store'});
    return res.end(JSON.stringify({ok:true,service:'Peer Server',port:PORT,path:PATH}));
  }
  res.writeHead(404, {'content-type':'application/json'});
  res.end(JSON.stringify({error:'Not found'}));
});

function emit(type, message, extra) {
  try {
    const bridge = require('nodejs-mobile-cordova');
    if (bridge && bridge.channel && typeof bridge.channel.post === 'function') {
      bridge.channel.post('message', Object.assign({type, message}, extra || {}));
    }
  } catch (_) {}
  console.log('[Peer Server] ' + message);
}

const peerServer = PeerServer({
  port: PORT,
  path: PATH,
  key: KEY,
  allow_discovery: false,
  expire_timeout: 5000,
  alive_timeout: 60000,
  proxied: false,
  debug: true
});

peerServer.on('connection', client => emit('log', 'Peer connected: ' + client.getId()));
peerServer.on('disconnect', client => emit('log', 'Peer disconnected: ' + client.getId()));
server.listen(PORT + 1, '127.0.0.1', () => {
  emit('status', 'Health endpoint ready on localhost:' + (PORT + 1), {online:true});
});
process.on('uncaughtException', err => emit('log', 'Uncaught exception: ' + err.message));
process.on('unhandledRejection', err => emit('log', 'Unhandled rejection: ' + String(err)));
