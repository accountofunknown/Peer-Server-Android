'use strict';
const fs = require('fs');
const path = require('path');

function mustExist(p) {
  if (!fs.existsSync(p)) {
    throw new Error('Missing required file: ' + p);
  }
}

mustExist('package.json');
mustExist('config.xml');
mustExist('www/index.html');
mustExist('www/nodejs-project/package.json');
mustExist('www/nodejs-project/main.js');

const rootPkg = JSON.parse(fs.readFileSync('package.json', 'utf8'));
const nodePkg = JSON.parse(fs.readFileSync('www/nodejs-project/package.json', 'utf8'));

if (!rootPkg.cordova || !rootPkg.cordova.plugins || !rootPkg.cordova.plugins['nodejs-mobile-cordova']) {
  throw new Error('nodejs-mobile-cordova must be declared in package.json → cordova.plugins');
}

if (!nodePkg.dependencies || !nodePkg.dependencies.peer) {
  throw new Error('www/nodejs-project must depend on "peer"');
}

const main = fs.readFileSync('www/nodejs-project/main.js', 'utf8');
if (!main.includes('PeerServer')) {
  throw new Error('main.js must create a PeerServer instance');
}

const html = fs.readFileSync('www/index.html', 'utf8');
if (!html.includes('deviceready')) {
  throw new Error('index.html must wait for Cordova deviceready');
}

console.log('Static project checks passed.');
