const fs=require('fs');
const assert=require('assert');
const p=JSON.parse(fs.readFileSync('package.json'));
const peer=JSON.parse(fs.readFileSync('www/nodejs-project/package.json'));
assert.equal(p.cordova.plugins['nodejs-mobile-cordova']!==undefined,true);
assert.equal(peer.dependencies.peer!==undefined,true);
assert(fs.readFileSync('www/nodejs-project/main.js','utf8').includes('PeerServer('));
assert(fs.readFileSync('www/index.html','utf8').includes('deviceready'));
console.log('Static project checks passed.');
