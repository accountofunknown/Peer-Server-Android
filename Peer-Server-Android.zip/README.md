# Peer Server — Android

**Package:** `android.peer.server`  
**App name:** Peer Server

Native Android app that runs a **PeerJS-compatible WebSocket signaling server** on your phone.

## Features

- WebSocket signaling on port **9000** (path `/peerjs`, key `peerjs`)
- HTTP health endpoint on port **9001** (`/healthz`)
- Foreground service + wake lock so the server stays alive
- Modern dark dashboard (status, peer count, LAN IP, copy buttons, live log)
- Works with PeerJS clients on the same Wi-Fi / LAN

## Client configuration

```js
const peer = new Peer(undefined, {
  host: "PHONE_LAN_IP",   // e.g. 192.168.1.42
  port: 9000,
  path: "/peerjs",
  key: "peerjs",
  secure: false,
  debug: 2
});
```

## Build APK with GitHub Actions

1. Put **`Peer-Server-Android.zip`** in the repository root.
2. Put **`.github/workflows/build-apk.yml`** in the repository (extract from the ZIP or use the standalone file).
3. Actions → **Build Peer Server APK from ZIP** → Run workflow.
4. Download the **Peer-Server-debug-APK** artifact.

## Local build

```bash
unzip Peer-Server-Android.zip -d project
cd project
./gradlew assembleDebug
```

APK: `app/build/outputs/apk/debug/app-debug.apk`

## Limitations

- Signaling only — not a TURN relay.
- Keep the app running (notification keeps the foreground service alive).
- Do not expose plain `ws://` to the public internet; use a reverse proxy with WSS for production.
