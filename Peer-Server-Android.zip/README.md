# Peer Server — Android

**Package ID:** `android.peer.server`  
**App name:** Peer Server

This is a Cordova Android application that embeds a real **PeerJS PeerServer** (signaling server) using the `nodejs-mobile-cordova` plugin. It is **not** a PeerJS client mock.

## Features

- Real `peer` package PeerServer running inside the app
- Listens on `0.0.0.0:9000` with path `/peerjs` and key `peerjs`
- Health endpoint at `/healthz`
- Modern dark dashboard with live status, LAN endpoint detection, copy buttons and runtime log
- GitHub Actions workflow that builds a debug APK from the ZIP file placed in the repository

## Important limitations

- Android may suspend networking when the app is backgrounded. Keep the app in the foreground while using it as a server.
- This is a **signaling** server only. Many WebRTC connections also need a TURN server.
- Do not expose the plain HTTP endpoint to the public internet. Use a reverse proxy with HTTPS for any production internet use.

## How to build the APK with GitHub Actions

1. Create a new GitHub repository.
2. Upload **two files** to the root of the repository:
   - `Peer-Server-Android.zip` (this archive)
   - `.github/workflows/build-apk.yml` (the workflow file is already inside the ZIP; extract it and place it at the path above, or copy it from the ZIP)
3. Go to **Actions → Build Peer Server APK from ZIP → Run workflow**.
4. When the run finishes, download the artifact named **Peer-Server-debug-APK**.

The workflow extracts the ZIP, installs Cordova + nodejs-mobile, builds a debug APK and uploads it as an artifact.

## Local build (optional)

Requires Node.js 18+, Java 17, Android SDK and NDK.

```bash
unzip Peer-Server-Android.zip -d project
cd project
npm install
npx cordova plugin add nodejs-mobile-cordova
npx cordova platform add android@13.0.0
npm install --prefix www/nodejs-project --omit=dev --no-bin-links
npx cordova build android --debug
```

APK location:

```
platforms/android/app/build/outputs/apk/debug/app-debug.apk
```

## PeerJS client configuration

```js
const peer = new Peer(undefined, {
  host: "PHONE_LAN_IP",   // e.g. 192.168.1.42
  port: 9000,
  path: "/peerjs",
  key: "peerjs",
  secure: false,
  debug: 2
});
```

Both devices must be able to reach each other on port 9000 (same Wi-Fi / LAN).

## Project layout

```
├── config.xml
├── package.json
├── scripts/check-project.js
├── www/
│   ├── index.html              # Dashboard UI
│   └── nodejs-project/
│       ├── package.json        # depends on "peer"
│       └── main.js             # starts PeerServer
└── .github/workflows/build-apk.yml
```
