# Peer Server — Android

Package ID: `android.peer.server`

This Cordova Android project embeds Node.js Mobile and runs the real `peer` package's `PeerServer` signaling server inside the app. It is not a PeerJS client-only mock.

## Features
- Embedded Node.js runtime via `nodejs-mobile-cordova`
- PeerServer listening on port 9000, path `/peerjs`, key `peerjs`
- Mobile dashboard with server endpoint, copy buttons, health checks, configuration guide and event/log view
- GitHub Actions workflow to build a debug APK and upload it as an artifact
- Supports local-network testing; internet access requires suitable routing/firewall and usually a public HTTPS reverse proxy for production

## Important limitations
- Android may suspend background work or stop networking when the app is backgrounded. This project is intended for foreground/local-network hosting; it is not a substitute for a managed always-on server.
- PeerServer is a signaling server, not a TURN server. Some WebRTC connections require separately configured STUN/TURN infrastructure.
- The Cordova Node.js Mobile plugin is an older native runtime integration. Build compatibility depends on upstream toolchains and may need maintenance as Android/Gradle/NDK versions change.
- The GitHub workflow attempts a reproducible CI build, but no APK has been built or tested on a physical device as part of generating this source archive.

## Build with GitHub Actions
1. Create a GitHub repository and upload the **contents** of this ZIP (not the ZIP file itself).
2. Ensure `.github/workflows/build-apk.yml` is present in the repository.
3. Open **Actions → Build Peer Server APK → Run workflow**, or push a commit.
4. Download the `Peer-Server-debug-APK` artifact from the completed run.

## Build locally
Requires Node.js/npm, Java 17, Android SDK, and Android NDK.
```bash
npm install
npm run prepare:android
cd platforms/android
./gradlew assembleDebug
```
APK output: `platforms/android/app/build/outputs/apk/debug/app-debug.apk`

## PeerJS client configuration
```js
const peer = new Peer(undefined, {
  host: "PHONE_LAN_IP",
  port: 9000,
  path: "/peerjs",
  key: "peerjs",
  secure: false,
  debug: 2
});
```
Use the phone's Wi-Fi/LAN IP address in place of `PHONE_LAN_IP`. Both devices must be able to reach each other on port 9000. Do not expose plain HTTP signaling to the public internet; use HTTPS via a reverse proxy for production.
