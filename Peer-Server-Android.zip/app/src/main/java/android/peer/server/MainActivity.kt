package android.peer.server

import android.Manifest
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.ServiceConnection
import android.content.pm.PackageManager
import android.net.wifi.WifiManager
import android.os.Build
import android.os.Bundle
import android.os.IBinder
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import java.util.Locale

class MainActivity : AppCompatActivity() {

    private lateinit var webView: WebView
    private var service: PeerServerService? = null
    private var bound = false

    private val connection = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName?, binder: IBinder?) {
            val local = binder as PeerServerService.LocalBinder
            service = local.getService()
            bound = true
            service?.logCallback = { msg -> runOnUiThread { injectLog(msg) } }
            service?.statusCallback = { online, count ->
                runOnUiThread { injectStatus(online, count) }
            }
            // Reflect current state
            injectStatus(service?.isOnline() == true, service?.peerCount() ?: 0)
        }

        override fun onServiceDisconnected(name: ComponentName?) {
            bound = false
            service = null
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        webView = findViewById(R.id.webView)

        requestNotificationPermission()
        setupWebView()
        startAndBindService()
    }

    private fun requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED
            ) {
                ActivityCompat.requestPermissions(
                    this,
                    arrayOf(Manifest.permission.POST_NOTIFICATIONS),
                    1001
                )
            }
        }
    }

    private fun setupWebView() {
        val settings: WebSettings = webView.settings
        settings.javaScriptEnabled = true
        settings.domStorageEnabled = true
        settings.allowFileAccess = true
        settings.mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
        webView.webChromeClient = WebChromeClient()
        webView.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView?, url: String?) {
                injectLanIp()
                injectStatus(service?.isOnline() == true, service?.peerCount() ?: 0)
            }
        }
        webView.addJavascriptInterface(Bridge(), "AndroidBridge")
        webView.loadUrl("file:///android_asset/dashboard.html")
    }

    private fun startAndBindService() {
        val intent = Intent(this, PeerServerService::class.java)
        ContextCompat.startForegroundService(this, intent)
        bindService(intent, connection, Context.BIND_AUTO_CREATE)
    }

    private fun injectLog(msg: String) {
        val safe = msg.replace("\\", "\\\\").replace("'", "\\'").replace("\n", " ")
        webView.evaluateJavascript("window.__onLog && window.__onLog('$safe')", null)
    }

    private fun injectStatus(online: Boolean, peers: Int) {
        webView.evaluateJavascript(
            "window.__onStatus && window.__onStatus($online, $peers)",
            null
        )
    }

    private fun injectLanIp() {
        val ip = getWifiIp() ?: "PHONE_IP"
        webView.evaluateJavascript("window.__onIp && window.__onIp('$ip')", null)
    }

    private fun getWifiIp(): String? {
        return try {
            val wm = applicationContext.getSystemService(WIFI_SERVICE) as WifiManager
            @Suppress("DEPRECATION")
            val ip = wm.connectionInfo.ipAddress
            if (ip == 0) return null
            String.format(
                Locale.US,
                "%d.%d.%d.%d",
                ip and 0xff,
                ip shr 8 and 0xff,
                ip shr 16 and 0xff,
                ip shr 24 and 0xff
            )
        } catch (_: Exception) {
            null
        }
    }

    inner class Bridge {
        @JavascriptInterface
        fun getLanIp(): String = getWifiIp() ?: "PHONE_IP"

        @JavascriptInterface
        fun isOnline(): Boolean = service?.isOnline() == true

        @JavascriptInterface
        fun peerCount(): Int = service?.peerCount() ?: 0

        @JavascriptInterface
        fun refreshStatus() {
            runOnUiThread {
                injectStatus(service?.isOnline() == true, service?.peerCount() ?: 0)
                injectLanIp()
            }
        }
    }

    override fun onDestroy() {
        if (bound) {
            unbindService(connection)
            bound = false
        }
        super.onDestroy()
    }
}
