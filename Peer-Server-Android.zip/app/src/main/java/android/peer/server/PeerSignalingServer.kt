package android.peer.server

import android.util.Log
import org.java_websocket.WebSocket
import org.java_websocket.handshake.ClientHandshake
import org.java_websocket.server.WebSocketServer
import org.json.JSONObject
import java.net.InetSocketAddress
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap

/**
 * Lightweight PeerJS-compatible signaling server.
 *
 * Clients connect with:
 *   ws://HOST:9000/peerjs?key=peerjs&id=PEER_ID&token=...
 *
 * Supports the core PeerJS message types used for offer/answer/candidate exchange.
 */
class PeerSignalingServer(
    private val port: Int = 9000,
    private val path: String = "/peerjs",
    private val key: String = "peerjs",
    private val onLog: (String) -> Unit = {},
    private val onStatus: (Boolean, Int) -> Unit = { _, _ -> }
) : WebSocketServer(InetSocketAddress("0.0.0.0", port)) {

    private val peers = ConcurrentHashMap<String, WebSocket>()
    private val peerMeta = ConcurrentHashMap<String, String>() // id -> token

    @Volatile
    var isRunning = false
        private set

    override fun onStart() {
        isRunning = true
        onStatus(true, peers.size)
        onLog("PeerServer listening on 0.0.0.0:$port$path (key=$key)")
        Log.i(TAG, "Server started on port $port")
    }

    override fun onOpen(conn: WebSocket, handshake: ClientHandshake) {
        val resource = handshake.resourceDescriptor ?: ""
        // Expected: /peerjs?key=peerjs&id=xxx&token=yyy  or  /peerjs/peerjs?id=...
        if (!resource.contains(path.trimStart('/')) && !resource.startsWith(path)) {
            // Allow bare path for health-style probes
        }

        val params = parseQuery(resource)
        val clientKey = params["key"] ?: key
        if (clientKey != key) {
            onLog("Rejected connection: invalid key")
            conn.close(1008, "Invalid key")
            return
        }

        var peerId = params["id"]
        if (peerId.isNullOrBlank()) {
            peerId = UUID.randomUUID().toString()
        }

        // If ID already taken, reject (PeerJS behaviour)
        if (peers.containsKey(peerId)) {
            sendJson(conn, JSONObject().apply {
                put("type", "ERROR")
                put("payload", JSONObject().put("msg", "ID is taken"))
            })
            conn.close(1008, "ID taken")
            onLog("Rejected duplicate ID: $peerId")
            return
        }

        peers[peerId] = conn
        peerMeta[peerId] = params["token"] ?: ""
        conn.setAttachment(peerId)

        // PeerJS OPEN message
        sendJson(conn, JSONObject().apply {
            put("type", "OPEN")
        })

        onStatus(true, peers.size)
        onLog("Peer connected: $peerId (total=${peers.size})")
    }

    override fun onClose(conn: WebSocket, code: Int, reason: String, remote: Boolean) {
        val peerId = conn.getAttachment<String>() ?: return
        peers.remove(peerId)
        peerMeta.remove(peerId)
        onStatus(isRunning, peers.size)
        onLog("Peer disconnected: $peerId (total=${peers.size})")
    }

    override fun onMessage(conn: WebSocket, message: String) {
        try {
            val json = JSONObject(message)
            val type = json.optString("type")
            val src = conn.getAttachment<String>() ?: return

            when (type) {
                "HEARTBEAT" -> {
                    // PeerJS keepalive – ignore or pong
                }
                "OFFER", "ANSWER", "CANDIDATE", "LEAVE" -> {
                    val dst = json.optString("dst")
                    if (dst.isBlank()) return
                    val target = peers[dst]
                    if (target != null && target.isOpen) {
                        // Forward with src filled
                        json.put("src", src)
                        target.send(json.toString())
                    } else {
                        // Notify source that peer is gone
                        sendJson(conn, JSONObject().apply {
                            put("type", "EXPIRE")
                            put("src", dst)
                        })
                    }
                }
                else -> {
                    // Unknown – try generic relay if dst present
                    val dst = json.optString("dst")
                    if (dst.isNotBlank()) {
                        val target = peers[dst]
                        if (target != null && target.isOpen) {
                            json.put("src", src)
                            target.send(json.toString())
                        }
                    }
                }
            }
        } catch (e: Exception) {
            onLog("Bad message: ${e.message}")
        }
    }

    override fun onError(conn: WebSocket?, ex: Exception) {
        onLog("Server error: ${ex.message}")
        Log.e(TAG, "WebSocket error", ex)
    }

    fun peerCount(): Int = peers.size

    fun stopServer() {
        try {
            stop(1000)
        } catch (_: Exception) {
        }
        isRunning = false
        peers.clear()
        peerMeta.clear()
        onStatus(false, 0)
        onLog("PeerServer stopped")
    }

    private fun sendJson(conn: WebSocket, obj: JSONObject) {
        if (conn.isOpen) {
            try {
                conn.send(obj.toString())
            } catch (_: Exception) {
            }
        }
    }

    private fun parseQuery(resource: String): Map<String, String> {
        val map = mutableMapOf<String, String>()
        val qIndex = resource.indexOf('?')
        if (qIndex < 0) return map
        val query = resource.substring(qIndex + 1)
        for (part in query.split('&')) {
            val kv = part.split('=', limit = 2)
            if (kv.size == 2) {
                map[kv[0]] = java.net.URLDecoder.decode(kv[1], "UTF-8")
            }
        }
        return map
    }

    companion object {
        private const val TAG = "PeerSignaling"
    }
}
