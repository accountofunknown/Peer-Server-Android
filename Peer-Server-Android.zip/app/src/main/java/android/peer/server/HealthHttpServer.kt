package android.peer.server

import android.util.Log
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.PrintWriter
import java.net.ServerSocket
import java.net.Socket
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Tiny HTTP server for /healthz and CORS preflight.
 * Runs on the same port as the WebSocket server is not possible,
 * so we use port+1 (9001) for health, or we multiplex.
 * For simplicity we bind health on 9001 and document both.
 *
 * Actually PeerJS clients only need the WS path. Dashboard uses 9001.
 */
class HealthHttpServer(
    private val port: Int = 9001,
    private val peerPort: Int = 9000,
    private val onLog: (String) -> Unit = {}
) {
    private val running = AtomicBoolean(false)
    private var serverSocket: ServerSocket? = null
    private val pool = Executors.newCachedThreadPool()

    fun start() {
        if (running.getAndSet(true)) return
        pool.execute {
            try {
                serverSocket = ServerSocket(port)
                onLog("Health HTTP on :$port")
                while (running.get()) {
                    try {
                        val client = serverSocket?.accept() ?: break
                        pool.execute { handle(client) }
                    } catch (_: Exception) {
                        if (!running.get()) break
                    }
                }
            } catch (e: Exception) {
                onLog("Health server error: ${e.message}")
                Log.e("HealthHttp", "start failed", e)
            }
        }
    }

    fun stop() {
        running.set(false)
        try {
            serverSocket?.close()
        } catch (_: Exception) {
        }
        serverSocket = null
    }

    private fun handle(socket: Socket) {
        try {
            socket.soTimeout = 5000
            val reader = BufferedReader(InputStreamReader(socket.getInputStream()))
            val writer = PrintWriter(socket.getOutputStream(), true)
            val requestLine = reader.readLine() ?: return
            // Drain headers
            while (true) {
                val line = reader.readLine() ?: break
                if (line.isEmpty()) break
            }

            val path = requestLine.split(" ").getOrNull(1) ?: "/"
            if (path.startsWith("/health") || path == "/") {
                val body = """{"ok":true,"service":"Peer Server","port":$peerPort,"path":"/peerjs","key":"peerjs"}"""
                writer.print("HTTP/1.1 200 OK\r\n")
                writer.print("Content-Type: application/json\r\n")
                writer.print("Access-Control-Allow-Origin: *\r\n")
                writer.print("Cache-Control: no-store\r\n")
                writer.print("Content-Length: ${body.toByteArray().size}\r\n")
                writer.print("\r\n")
                writer.print(body)
            } else if (requestLine.startsWith("OPTIONS")) {
                writer.print("HTTP/1.1 204 No Content\r\n")
                writer.print("Access-Control-Allow-Origin: *\r\n")
                writer.print("Access-Control-Allow-Methods: GET, OPTIONS\r\n")
                writer.print("Access-Control-Allow-Headers: *\r\n")
                writer.print("\r\n")
            } else {
                writer.print("HTTP/1.1 404 Not Found\r\nContent-Length: 0\r\n\r\n")
            }
            writer.flush()
        } catch (_: Exception) {
        } finally {
            try {
                socket.close()
            } catch (_: Exception) {
            }
        }
    }
}
