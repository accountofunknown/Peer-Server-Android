package android.peer.server

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.os.Binder
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import androidx.core.app.NotificationCompat

class PeerServerService : Service() {

    private val binder = LocalBinder()
    private var signaling: PeerSignalingServer? = null
    private var health: HealthHttpServer? = null
    private var wakeLock: PowerManager.WakeLock? = null

    var logCallback: ((String) -> Unit)? = null
    var statusCallback: ((Boolean, Int) -> Unit)? = null

    inner class LocalBinder : Binder() {
        fun getService(): PeerServerService = this@PeerServerService
    }

    override fun onBind(intent: Intent?): IBinder = binder

    override fun onCreate() {
        super.onCreate()
        createChannel()
        val pm = getSystemService(POWER_SERVICE) as PowerManager
        wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "PeerServer::Wake").apply {
            setReferenceCounted(false)
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startForeground(NOTIFICATION_ID, buildNotification(0))
        startServers()
        return START_STICKY
    }

    private fun startServers() {
        if (signaling?.isRunning == true) return

        wakeLock?.acquire(4 * 60 * 60 * 1000L) // 4h max

        signaling = PeerSignalingServer(
            port = 9000,
            onLog = { msg -> logCallback?.invoke(msg) },
            onStatus = { online, count ->
                statusCallback?.invoke(online, count)
                updateNotification(count)
            }
        )
        try {
            signaling?.start()
        } catch (e: Exception) {
            logCallback?.invoke("Failed to start signaling: ${e.message}")
        }

        health = HealthHttpServer(port = 9001, peerPort = 9000) { msg ->
            logCallback?.invoke(msg)
        }
        health?.start()
    }

    fun stopServers() {
        signaling?.stopServer()
        signaling = null
        health?.stop()
        health = null
        if (wakeLock?.isHeld == true) wakeLock?.release()
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    fun isOnline(): Boolean = signaling?.isRunning == true
    fun peerCount(): Int = signaling?.peerCount() ?: 0

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                getString(R.string.notification_channel),
                NotificationManager.IMPORTANCE_LOW
            )
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(channel)
        }
    }

    private fun buildNotification(peers: Int): Notification {
        val intent = Intent(this, MainActivity::class.java)
        val pi = PendingIntent.getActivity(
            this, 0, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle(getString(R.string.notification_title))
            .setContentText("Port 9000 · $peers peer(s)")
            .setSmallIcon(R.drawable.ic_launcher)
            .setContentIntent(pi)
            .setOngoing(true)
            .setSilent(true)
            .build()
    }

    private fun updateNotification(peers: Int) {
        val nm = getSystemService(NotificationManager::class.java)
        nm.notify(NOTIFICATION_ID, buildNotification(peers))
    }

    override fun onDestroy() {
        stopServers()
        super.onDestroy()
    }

    companion object {
        const val CHANNEL_ID = "peer_server"
        const val NOTIFICATION_ID = 9000
    }
}
