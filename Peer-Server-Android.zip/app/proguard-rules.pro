# Peer Server – keep WebSocket and JSON classes
-keep class org.java_websocket.** { *; }
-keep class org.json.** { *; }
